const submitBtn = document.querySelector('input[type="button"]');
const firstInput = document.getElementById('first-number');
const secondInput = document.getElementById('second-number');
const resultField = document.querySelector('.result')

const multiply = () => {
  if (!firstInput.value || !secondInput.value) {
    alert('Заполните все поля!');
    return;
  }
  const result = firstInput.value * secondInput.value;
  resultField.innerHTML = result;
}

submitBtn.onclick = multiply;