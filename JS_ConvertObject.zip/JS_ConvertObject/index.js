const colorObject = {
  red: 98,
  green: 0,
  blue: 98,
}

const convertColorObj = (obj => {
  return `rgb(${obj.red},${obj.green},${obj.blue}`;
})

const setBackgroundColor = (() => {
  document.body.style.backgroundColor = convertColorObj(colorObject);
})

setBackgroundColor();