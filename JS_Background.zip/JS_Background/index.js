const body = document.body;
const backgroundImage = 'url(images/cats.jpeg)';

const setPageBackground = () => {
  document.body.style.backgroundImage = backgroundImage;
}


setPageBackground();